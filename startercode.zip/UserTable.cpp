#include "UserTable.h"

using namespace std;

UserTable::UserTable (int tablesize) {
  M = tablesize;
  assert (M > 0);
  table = new User[M];
  assert (table != NULL);
  for (int i=0; i<M; ++i)
    table[i].empty = true;
}

// De-allocate memory in destructor
UserTable::~UserTable() {
  delete [] table;
}

// Searches for a user with the given IP address.
// A pointer to the string containing the username is returned,
// or NULL is returned if the IP address is not found.
const string* UserTable::search (const IP &k) const {
  // TODO
  return NULL;
}

// Inserts a new user into the hash table.
// The return value is "true" if the new item was successfully
// inserted, or "false" if an infinite loop was found.
bool UserTable::insert (const IP &ipaddr, const string username) {
  // TODO
  return false;
}

// Searches for a user with the given IP address in the table,
// and if found, removes that user from the table.
void UserTable::remove (const IP &k) {
  // TODO
}

// Prints out all the contents of this table to out.
void UserTable::dump (ostream &out) {
  for (int i = 0; i < M; ++i) {
    out << i << '\t';
    if (table[i].empty) out << "(empty)";
    else out << table[i].ipaddr.getIPString()
             << ' ' << table[i].username;
    out << endl;
  }
}

