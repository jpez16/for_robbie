#include <cstdlib>
#include <string>
#include <iostream>
#include <fstream>

#include "UserTable.h"

using namespace std;

int main(int argc, char **argv) {
  int M;

  if (argc != 2) {
    cout << "Usage: " << argv[0] << " <table_size>" << endl;
    return 1;
  }

  M = atoi(argv[1]);

  // TODO:
  // Create the table

  // Read lines of the form "<ip_address> <username>"
  
  // Create IP object

  // Try inserting into table

  // If insertion fails, done
  // Else read the next line.

  // Print number of successful insertions, followed by blankline,
  // followed by dump().

  return 0;
}
